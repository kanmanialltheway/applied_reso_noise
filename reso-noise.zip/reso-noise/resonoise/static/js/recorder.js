// Microphone capture to 16-bit mono WAV. Browser audio processing is switched off so the raw signal is analysed.
const WORKLET = `class Cap extends AudioWorkletProcessor {
  process(inputs) { const ch = inputs[0][0]; if (ch) this.port.postMessage(ch.slice(0)); return true; }
}
registerProcessor('reso-capture', Cap);`;

export function encodeWav(chunks, sampleRate) {
  let n = 0;
  for (const c of chunks) n += c.length;
  const buf = new ArrayBuffer(44 + n * 2);
  const v = new DataView(buf);
  const w = (o, s) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
  w(0, "RIFF"); v.setUint32(4, 36 + n * 2, true); w(8, "WAVE"); w(12, "fmt ");
  v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
  v.setUint32(24, sampleRate, true); v.setUint32(28, sampleRate * 2, true);
  v.setUint16(32, 2, true); v.setUint16(34, 16, true); w(36, "data"); v.setUint32(40, n * 2, true);
  let o = 44;
  for (const c of chunks) for (let i = 0; i < c.length; i++, o += 2) {
    const s = Math.max(-1, Math.min(1, c[i]));
    v.setInt16(o, s < 0 ? s * 32768 : s * 32767, true);
  }
  return new Blob([buf], { type: "audio/wav" });
}

export class Recorder {
  constructor({ maxSeconds = 120, onLevel, onTick, onAutoStop }) {
    Object.assign(this, { maxSeconds, onLevel, onTick, onAutoStop });
    this.chunks = []; this.samples = 0; this.active = false;
  }

  static supported() {
    return !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia && (window.AudioContext || window.webkitAudioContext));
  }

  async start() {
    if (!Recorder.supported()) throw new Error("This browser cannot record audio. Upload a file instead.");
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false, channelCount: 1 },
      });
    } catch (e) {
      const map = {
        NotAllowedError: "Microphone access was blocked. Allow it in the browser's site settings and try again.",
        NotFoundError: "No microphone was found on this device.",
        NotReadableError: "The microphone is in use by another application.",
      };
      throw new Error(map[e.name] || `Could not open the microphone (${e.name || e.message}).`);
    }
    const AC = window.AudioContext || window.webkitAudioContext;
    this.ctx = new AC();
    if (this.ctx.state === "suspended") await this.ctx.resume();
    this.source = this.ctx.createMediaStreamSource(this.stream);
    this.analyser = this.ctx.createAnalyser();
    this.analyser.fftSize = 1024;
    this.source.connect(this.analyser);
    const sink = this.ctx.createGain();
    sink.gain.value = 0;
    sink.connect(this.ctx.destination);
    const push = (data) => {
      if (!this.active) return;
      this.chunks.push(data); this.samples += data.length;
      if (this.samples / this.ctx.sampleRate >= this.maxSeconds) this.onAutoStop && this.onAutoStop();
    };
    try {
      const url = URL.createObjectURL(new Blob([WORKLET], { type: "application/javascript" }));
      await this.ctx.audioWorklet.addModule(url);
      URL.revokeObjectURL(url);
      this.node = new AudioWorkletNode(this.ctx, "reso-capture");
      this.node.port.onmessage = (e) => push(e.data);
    } catch (e) {                                   // older browsers
      this.node = this.ctx.createScriptProcessor(4096, 1, 1);
      this.node.onaudioprocess = (e) => push(new Float32Array(e.inputBuffer.getChannelData(0)));
    }
    this.source.connect(this.node);
    this.node.connect(sink);
    this.active = true;
    this.t0 = performance.now();
    const buf = new Float32Array(this.analyser.fftSize);
    const loop = () => {
      if (!this.active) return;
      this.analyser.getFloatTimeDomainData(buf);
      let s = 0; for (const x of buf) s += x * x;
      this.onLevel && this.onLevel(Math.sqrt(s / buf.length), Math.max(...buf.map(Math.abs)));
      this.onTick && this.onTick(this.samples / this.ctx.sampleRate);
      this.raf = requestAnimationFrame(loop);
    };
    loop();
  }

  async stop() {
    this.active = false;
    cancelAnimationFrame(this.raf);
    const rate = this.ctx.sampleRate;
    try { this.node.disconnect(); this.source.disconnect(); } catch (e) { /* already gone */ }
    this.stream.getTracks().forEach((t) => t.stop());
    await this.ctx.close();
    const blob = encodeWav(this.chunks, rate);
    const seconds = this.samples / rate;
    this.chunks = []; this.samples = 0;
    return { blob, seconds };
  }

  cancel() {
    if (!this.active) return;
    this.active = false;
    cancelAnimationFrame(this.raf);
    this.stream && this.stream.getTracks().forEach((t) => t.stop());
    this.ctx && this.ctx.close();
    this.chunks = []; this.samples = 0;
  }
}
